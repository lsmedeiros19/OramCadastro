
 
O servi�o criou os seguintes arquivos com configura��es 

Global.asax
WebApiConfig
Webconfig 
	AppSettings

Checar se n�o houve problema na sobreescrita.


WebConfig

DisableFilter - >  AuthenticationFilter,AuthorizationFilter



Altere o nome a caminho do arquivo de log em serilog:write-to:RollingFile.pathFormat

